//AT30TS75A ��ֵʽ�¶ȼ� IIC�ӿ�
#ifndef __AT30TS75A_H__
#define __AT30TS75A_H__

#include<STC8.h>

char Read_AT30TS75A(void);

#endif







